<html>
    <head>
        <title>Bangladesh Railway</title>
    </head>
    <body>
        <h1>BANGLADESH RAILWAY</h1>
        <p>This is Bangladesh Railway database control system.</p></br>
        <form action = "admin.php" method ="post">
            <table>
                <tr>
                    <td><input type = "submit" name = "submit" value="Admin"></td>
                </tr>

            </table>
        </form>
        <form action = "user.php" method ="post">
            <table>
                <tr>
                    <td><input type = "submit" name = "submit" value="User"></td>
                </tr>
            </table>
        </form>
    </body>
</html>