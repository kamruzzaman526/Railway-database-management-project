<?php

$username = "root";
$password = "";
$server = 'localhost';
$db = 'railway';

$con = mysqli_connect($server,$username,$password,$db);


?>