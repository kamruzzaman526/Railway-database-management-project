
<html>
    <head>
        <title>
        </title>
    </head>
    <body>
        
        <h1>WELCOME, ADMIN</h1>
        <p>....................................................................</p>
        <form action="home.php" method="post">
             <table>
                 <tr>
                     <td><input type ="submit" name ="submit" value="Back"></td>
                 </tr>
             </table>
         </form>
        <p>CHOOSE YOUR OPTION TO EDIT</p>
        <form action = "index.php" method ="post">

                    <td><input type = "submit" name = "submit" value="Train Schedule"></td>
                </tr>

            </table>
        </form>
         <form action = "s_index.php" method ="post">

                    <td><input type = "submit" name = "submit" value="Railway Station Info"></td>
                </tr>

            </table>
        </form>
        
         <form action = "m_index.php" method ="post">

                    <td><input type = "submit" name = "submit" value="Station Master Info"></td>
                </tr>

            </table>
        </form>

         <form action = "e_index.php" method ="post">

                    <td><input type = "submit" name = "submit" value="Railway Employees Info"></td>
                </tr>

            </table>
        </form>

                 <form action = "t_index.php" method ="post">

                    <td><input type = "submit" name = "submit" value="TTE Info"></td>
                </tr>

            </table>
        </form>
                <form action = "p_index.php" method ="post">

                    <td><input type = "submit" name = "submit" value="LocoMaster Info"></td>
                </tr>

            </table>
        </form>



    </body>
</html>
