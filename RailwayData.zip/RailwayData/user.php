
<html>
    <head>
        <title>
        </title>
    </head>
    <body>
        <h1>WELCOME, USER</h1>
       
        <p>....................................................................</p>
        <form action="home.php" method="post">
             <table>
                 <tr>
                     <td><input type ="submit" name ="submit" value="Back"></td>
                 </tr>
             </table>
         </form>
         <p>CHOOSE YOUR OPTION TO SEE:</p>
        <form action = "user_train_table.php" method ="post">

                    <td><input type = "submit" name = "submit" value="Train Schedule"></td>
                </tr>

            </table>
        </form>
         <form action = "user_s_table.php" method ="post">

                    <td><input type = "submit" name = "submit" value="Railway Station Info"></td>
                </tr>

            </table>
        </form>
        
         <form action = "user_m_table.php" method ="post">

                    <td><input type = "submit" name = "submit" value="Station Master Info"></td>
                </tr>

            </table>
        </form>

         <form action = "user_e_table.php" method ="post">

                    <td><input type = "submit" name = "submit" value="Railway Employees Info"></td>
                </tr>

            </table>
        </form>
        </form>
                 <form action = "user_t_table.php" method ="post">

                    <td><input type = "submit" name = "submit" value="TTE Info."></td>
                </tr>

            </table>
        </form>
        <form action = "user_p_table.php" method ="post">

                    <td><input type = "submit" name = "submit" value="LocoMaster Info"></td>
                </tr>

            </table>





    </body>
</html>
